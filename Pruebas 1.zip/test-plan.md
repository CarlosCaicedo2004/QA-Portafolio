# Test Plan — SauceDemo E-commerce Web App

## 1. Introducción
Este documento describe el plan de pruebas funcionales para la aplicación web [SauceDemo](https://www.saucedemo.com), un sitio de e-commerce de práctica utilizado para demostrar habilidades de QA manual.

## 2. Objetivo
Validar que los flujos principales de la aplicación (autenticación, catálogo de productos, carrito de compras y checkout) funcionen correctamente según el comportamiento esperado, e identificar defectos que puedan afectar la experiencia del usuario.

## 3. Alcance

### Dentro del alcance
- Login / Logout (incluyendo usuarios con diferentes comportamientos: `standard_user`, `locked_out_user`, `problem_user`, `performance_glitch_user`)
- Listado y ordenamiento de productos (por nombre y precio)
- Agregar/quitar productos del carrito
- Flujo completo de checkout (datos del comprador, resumen de orden, confirmación)
- Navegación general (menú lateral, breadcrumbs, botones "back")

### Fuera del alcance
- Pruebas de rendimiento y carga
- Pruebas de seguridad (penetration testing)
- Compatibilidad cross-browser exhaustiva (se probará solo en Chrome de escritorio)
- Pruebas de accesibilidad (WCAG)

## 4. Estrategia de pruebas
- **Tipo de pruebas:** Funcionales, de regresión y exploratorias
- **Técnicas de diseño:** Particionamiento de equivalencia, análisis de valores límite, tablas de decisión para combinaciones de usuario/credenciales
- **Enfoque:** Pruebas manuales basadas en casos de prueba documentados, complementadas con pruebas exploratorias libres para detectar comportamientos inesperados (SauceDemo incluye usuarios con bugs intencionales, ideales para practicar detección de defectos)

## 5. Criterios de entrada
- La aplicación está disponible y accesible en https://www.saucedemo.com
- Los casos de prueba han sido diseñados y revisados

## 6. Criterios de salida
- 100% de los casos de prueba planificados han sido ejecutados
- Todos los defectos críticos y altos están documentados y reportados
- No quedan bloqueadores sin registrar

## 7. Ambiente de pruebas
- **Navegador:** Google Chrome (última versión estable)
- **Sistema operativo:** Windows / Linux
- **URL:** https://www.saucedemo.com
- **Usuarios de prueba:** provistos públicamente por SauceDemo (standard_user, locked_out_user, problem_user, performance_glitch_user, error_user, visual_user) — contraseña: `secret_sauce`

## 8. Entregables
- Este test plan
- Conjunto de casos de prueba (`test-cases.md` / `.csv`)
- Reportes de bugs encontrados (`bug-reports/`)

## 9. Riesgos
| Riesgo | Impacto | Mitigación |
|---|---|---|
| El sitio es de práctica y puede cambiar sin previo aviso | Medio | Validar casos antes de cada ejecución |
| Usuarios especiales (problem_user, etc.) tienen bugs intencionales | Bajo (es esperado) | Documentarlos como hallazgos, no como fallos reales del sistema |

## 10. Roles
- **Diseño y ejecución de pruebas:** [Tu nombre]
- **Reporte de defectos:** [Tu nombre]
