# BUG-001: Imágenes de productos incorrectas al usar problem_user

## Resumen
Al iniciar sesión con el usuario `problem_user`, las imágenes de los productos en el catálogo no corresponden a los productos reales; todas muestran la misma imagen (un perro), independientemente del producto.

## Entorno
- **URL:** https://www.saucedemo.com
- **Navegador:** Chrome (última versión estable)
- **Usuario:** problem_user / secret_sauce

## Pasos para reproducir
1. Ir a https://www.saucedemo.com
2. Iniciar sesión con usuario `problem_user` y contraseña `secret_sauce`
3. Observar las imágenes en la página de inventario (products.html)

## Resultado actual
Todas las tarjetas de producto muestran la misma imagen (un perro), sin importar el nombre o tipo de producto.

## Resultado esperado
Cada producto debería mostrar su imagen correspondiente (camiseta, mochila, etc.), tal como ocurre con `standard_user`.

## Severidad / Prioridad
- **Severidad:** Media (afecta la experiencia visual pero no bloquea la funcionalidad)
- **Prioridad:** Baja (es un usuario de prueba diseñado específicamente para exhibir este bug)

## Evidencia
_Adjuntar captura de pantalla del catálogo mostrando las imágenes duplicadas._

## Notas
Este comportamiento es intencional en SauceDemo: `problem_user` está diseñado para exhibir bugs visuales con fines de práctica de QA. Se documenta aquí como ejercicio de reporte de defectos.
